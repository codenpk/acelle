<?php 
# +------------------------------------------------------------------------+
# | Artlantis CMS Solutions                                                |
# +------------------------------------------------------------------------+
# | Lethe Newsletter & Mailing System                                      |
# | Copyright (c) Artlantis Design Studio 2014. All rights reserved.       |
# | Version       2.0                                                      |
# | Last modified 19.11.2014                                               |
# | Email         developer@artlantis.net                                  |
# | Web           http://www.artlantis.net                                 |
# +------------------------------------------------------------------------+

$LETHE_MAIL_ENGINE['swiftmailer'] = array(
											'title'=>'Swift Mailer',
											'init'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'init.engine.php'
										);
?>
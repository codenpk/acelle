<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Lethe Newsletter & Mailing System</title>
<!-- styles -->
<link rel="stylesheet" href="bootstrap/dist/css/bootstrap.min.css">
<link href="css/footable.core.css" rel="stylesheet" type="text/css">
<link href="css/footable.standalone.min.css" rel="stylesheet" type="text/css">
<link href="css/ionCheck/ion.checkRadio.css" rel="stylesheet" type="text/css">
<link href="css/ionCheck/ion.checkRadio.cloudy.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="css/jquery.switchButton.css">
<link rel="stylesheet" href="css/jquery.fancybox.css">
<link rel="stylesheet" href="css/lethe.css">
<link rel="stylesheet" href="css/lethe.responsive.css">
<link rel="stylesheet" href="bootstrap/dist/css/<?php echo(lethe_theme);?>_bootstrap.min.css">

<!-- scripts -->
<script src="Scripts/jquery-1.11.1.min.js"></script>
<!-- lethe notices -->
<link rel="stylesheet" href="css/ticker-style.css">
<script src="Scripts/jquery.ticker.js"></script>
<script src="Scripts/holder.min.js"></script>
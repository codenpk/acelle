<?php
/**
 * Created by PhpStorm.
 * User: mithun
 * Date: 3/3/16
 * Time: 4:49 PM
 */

?>
Click here to reset your password: {{ url('password/reset/'.$token) }}
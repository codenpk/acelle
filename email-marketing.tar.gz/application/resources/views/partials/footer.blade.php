<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.1
    </div>
    <strong>Copyright © {{date('Y')}} <a href="#">xcoder.io</a>.</strong> All rights
    reserved.
</footer>